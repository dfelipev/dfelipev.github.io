---
title: 'Javascript côté serveur'
date: '2016-03-03'
---

Le javascript côté serveur, ça a quand même l'air sympa! Je n'ai pas encore pu constater la performance annoncée car je n'ai pas stressé mes petites applis d'exemple mais c'est pas si prise de tête que prévu. Faut pas déconner non plus, les callbacks on connaît un peu.
J'ai donc bossé les cours de [codeschool](http://www.codeschool.com) sur _nodejs_ et _expressjs_. Bon, ces tutos sont pal mal du tout mais alors les séquences "Soup to bits" genre [Soup to Bits: Building Blocks of Express.js](https://www.codeschool.com/screencasts/soup-to-bits-building-blocks-of-express-js) sont de vrais petits bijoux avec le boss et un développeur qui codent un application from scratch dans la techno abordée. A la fin, y'a de supers pointeurs et devinez quoi ? Les vidéos et slides sont téléchargeables... y'a même le pointeur vers les sources finalisées sur Github. Bref, la classe. Accès à TOUS les cours pour moins de 300\$/an ! Va falloir que je me reconvertisse en commercial de chez codeschool parce que j'a.d.o.r.e.

Je continue donc mon chemin dans le monde "fabuleux" du javascript tout en rassurant mon Python (je t'aime encore et toujours). La suite sera emberjs, react et redux. Du lourd!
